OK_FORMAT = True

test = {'name': 'q5a', 'points': 1, 'suites': [{'cases': [{'code': ">>> a = torch.tensor([1, 2, 3, 4, 5])\n>>> assert sum(a) == 15, 'Sum incorrect for [1, 2, 3, 4, 5]'\n>>> b = torch.tensor([1, -1, 1, -1])\n>>> assert sum(b) == 0, 'Sum incorrect for alternating sequence'\n", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}