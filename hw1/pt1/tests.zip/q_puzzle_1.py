OK_FORMAT = True

test = {'name': 'q_puzzle_1', 'points': 1, 'suites': [{'cases': [{'code': ">>> assert torch.all(ones(5) == torch.ones(5)), 'ones(5) incorrect'\n>>> assert torch.all(ones(1) == torch.ones(1)), 'ones(1) incorrect'\n>>> print('Puzzle 1 passed!')\n", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}