OK_FORMAT = True

test = {'name': 'q5b', 'points': 1, 'suites': [{'cases': [{'code': ">>> a = torch.tensor([1, 2, 3])\n>>> b = torch.tensor([4, 5])\n>>> out = outer(a, b)\n>>> expected = torch.outer(a, b)\n>>> assert torch.all(out == expected), 'Outer product incorrect'\n", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}