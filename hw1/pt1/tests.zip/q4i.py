OK_FORMAT = True

test = {'name': 'q4i', 'points': 2, 'suites': [{'cases': [{'code': ">>> assert 'aug_performance' in locals(), 'aug_performance DataFrame not found. Did you create it using groupby and agg operations?'\n", 'hidden': False, 'locked': False, 'points': 1}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}