OK_FORMAT = True

test = {'name': 'q8cii', 'points': 2, 'suites': [{'cases': [{'code': ">>> for col in ['unrotated_prediction', 'unrotated_correct']:\n...     assert col in test_secret_df.columns\n>>> assert test_secret_df['unrotated_correct'].dtype == bool\n", 'hidden': False, 'locked': False, 'points': 1}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}