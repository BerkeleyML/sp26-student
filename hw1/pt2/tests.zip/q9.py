OK_FORMAT = True

test = {'name': 'q9', 'points': 5, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}